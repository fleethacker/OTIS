import "../route-registry";
import { expect, test } from "bun:test";
import { create } from "@bufbuild/protobuf";
import { timestampFromDate } from "@bufbuild/protobuf/wkt";
import { fireEvent } from "@testing-library/react";
import { renderWithProviders } from "../test-utils/render";
import { MessageRecordSchema } from "../gen/app/v1/models_pb";
import { MessageReader } from "../components/message-reader";
import Messages from "./messages";

test("message page mounts truthful loading and keyboard search", () => {
  const view = renderWithProviders(<Messages />, { route: "/messages?record=missing" });
  expect(view.getByRole("searchbox", { name: "Search Message records" })).toBeTruthy();
  expect(view.getByRole("status").textContent).toContain("Loading");
});
test("reader preserves missing information and switches views", () => {
  const message = create(MessageRecordSchema, {
    sourceMessageId: "test-source",
    provenance: "fictional",
    rawText: "Illustrative line",
    events: [{ title: "Unresolved activity", scheduleStatus: "needs_review" }],
  });
  const view = renderWithProviders(<MessageReader message={message} />);
  expect(view.getByText(/Fictional USS Meridian/)).toBeTruthy();
  expect(view.getByRole("button", { name: "Summarize" }).hasAttribute("disabled")).toBe(true);
  expect(view.getAllByRole("tab").map((tab) => tab.textContent)).toEqual([
    "Parsed fields",
    "Raw message",
    "Lifecycle",
  ]);
  expect(view.getByRole("tab", { name: "Raw message" }).getAttribute("aria-selected")).toBe(
    "false"
  );
  expect(view.getByRole("tab", { name: "Parsed fields" }).getAttribute("aria-selected")).toBe(
    "true"
  );
  expect(view.getByText(/Needs review/)).toBeTruthy();
  expect(view.getAllByText("Unavailable").length).toBeGreaterThan(0);
  fireEvent.click(view.getByRole("tab", { name: "Raw message" }));
  expect(view.getByRole("tab", { name: "Raw message" }).getAttribute("aria-selected")).toBe("true");
  expect(view.getByRole("tab", { name: "Parsed fields" }).getAttribute("aria-selected")).toBe(
    "false"
  );
  expect(view.getByText("Illustrative line")).toBeTruthy();
});

test("reader tabs use roving focus and associated panels", () => {
  const view = renderWithProviders(<MessageReader message={create(MessageRecordSchema)} />);
  const tabs = view.getAllByRole("tab");
  const select = (index: number) => {
    for (const [i, tab] of tabs.entries()) {
      expect(tab.getAttribute("aria-selected")).toBe(String(i === index));
      expect(tab.tabIndex).toBe(i === index ? 0 : -1);
    }
    const panel = view.getByRole("tabpanel");
    expect(panel.id).toBe(tabs[index].getAttribute("aria-controls")!);
    expect(panel.getAttribute("aria-labelledby")).toBe(tabs[index].id);
  };
  select(0);
  tabs[0].focus();
  for (const [key, index] of [
    ["ArrowRight", 1],
    ["ArrowRight", 2],
    ["ArrowRight", 0],
    ["ArrowLeft", 2],
    ["Home", 0],
    ["End", 2],
  ] as const) {
    fireEvent.keyDown(document.activeElement!, { key });
    select(index);
    expect(document.activeElement).toBe(tabs[index]);
  }
});

test("lifecycle renders supplied repeated milestones, UTC boundaries and unavailable time", () => {
  const at = (value: string) => timestampFromDate(new Date(value));
  const message = create(MessageRecordSchema, {
    sourceMessageId: "fictional-history",
    processingStatus: "updated",
    lifecycleEntries: [
      {
        id: "first",
        milestone: "parsed",
        recordedAt: at("2026-11-04T23:59:00Z"),
        detail: "First fictional parse",
        provenance: "fictional",
      },
      {
        id: "again",
        milestone: "parsed",
        recordedAt: at("2026-11-05T00:00:00Z"),
        detail: "Repeated fictional parse",
      },
      { id: "review", milestone: "reviewed", detail: "Undated fictional review" },
    ],
  });
  const view = renderWithProviders(<MessageReader message={message} />);
  fireEvent.click(view.getByRole("tab", { name: "Lifecycle" }));
  const panel = view.getByRole("tabpanel");
  expect(panel.textContent).toContain("2026-11-04 23:59 UTC");
  expect(panel.textContent).toContain("2026-11-05 00:00 UTC");
  expect(panel.textContent).toMatch(/time unavailable/i);
  expect(panel.textContent!.indexOf("First fictional parse")).toBeLessThan(
    panel.textContent!.indexOf("Repeated fictional parse")
  );
  expect(panel.textContent).toContain("Undated fictional review");
  expect(panel.textContent).not.toMatch(/Acknowledged/);
});

test("absent lifecycle remains unavailable rather than inferred from processing status", () => {
  const view = renderWithProviders(
    <MessageReader message={create(MessageRecordSchema, { processingStatus: "parsed" })} />
  );
  fireEvent.click(view.getByRole("tab", { name: "Lifecycle" }));
  const panel = view.getByRole("tabpanel");
  expect(panel.textContent).toMatch(/unavailable/i);
  expect(panel.querySelectorAll("time").length).toBe(0);
  expect(panel.textContent).not.toMatch(/Acknowledged/);
});
