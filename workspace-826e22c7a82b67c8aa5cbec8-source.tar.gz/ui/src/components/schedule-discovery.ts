import type { MessageRecord } from "../gen/app/v1/models_pb";
import { geometry, instant } from "./calendar-time";

export function discover(messages: MessageRecord[], query: string, now: number) {
  const q = query.trim().toLowerCase();
  const matches = (values: (string | undefined)[]) => values.join("\n").toLowerCase().includes(q);
  const filtered = messages
    .map((message) => {
      const shared = [message.rawText, message.sourceMessageId];
      return {
        ...message,
        events: message.events.filter((event) =>
          matches([...shared, event.title, event.unit, event.location])
        ),
      };
    })
    .filter(
      (message) =>
        message.events.length > 0 ||
        (message.processingStatus === "needs_review" &&
          matches([message.rawText, message.sourceMessageId, message.subject]))
    );
  const rows = filtered.flatMap((message) => message.events.map((event) => ({ message, event })));
  const timed = rows
    .filter(({ event }) => geometry(event, -8.64e15, 8.64e15))
    .sort((a, b) => instant(a.event.startAt) - instant(b.event.startAt));
  const review = filtered.filter(
    (message) =>
      message.processingStatus === "needs_review" ||
      message.events.some((event) => !geometry(event, -8.64e15, 8.64e15))
  );
  return {
    messages: filtered,
    timed,
    upcoming: timed.filter(({ event }) => instant(event.startAt) >= now).slice(0, 5),
    review,
  };
}
