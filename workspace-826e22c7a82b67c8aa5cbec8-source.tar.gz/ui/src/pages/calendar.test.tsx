import "../route-registry";
import { expect, test } from "bun:test";
import { create } from "@bufbuild/protobuf";
import { timestampFromDate } from "@bufbuild/protobuf/wkt";
import { renderWithProviders } from "../test-utils/render";
import { ExtractedEventSchema, MessageRecordSchema } from "../gen/app/v1/models_pb";
import { DayTimeline } from "../components/day-timeline";
import { geometry, HOUR, utcDate, monthBounds, moveMonth } from "../components/calendar-time";
import Calendar from "./calendar";
import { discover } from "../components/schedule-discovery";

const midnight = Date.parse("2026-11-04T00:00:00Z");
const event = create(ExtractedEventSchema, {
  id: 1n,
  title: "Short event",
  scheduleStatus: "confirmed",
  startAt: timestampFromDate(new Date(midnight + 8.25 * HOUR)),
  endAt: timestampFromDate(new Date(midnight + 8.5 * HOUR)),
});
test("actual UTC month lengths, exact fractions and keyboard day controls", () => {
  for (const [date, days] of [
    ["2025-02-01", 28],
    ["2024-02-01", 29],
    ["2026-11-01", 30],
    ["2026-12-01", 31],
  ] as const) {
    const bounds = monthBounds(date);
    expect(bounds.days).toBe(days);
    const short = {
      ...event,
      startAt: timestampFromDate(new Date(bounds.from + 8.25 * HOUR)),
      endAt: timestampFromDate(new Date(bounds.from + 8.5 * HOUR)),
    };
    expect(geometry(short, bounds.from, bounds.to)?.width).toBeCloseTo(
      (100 * 0.25) / (days * 24),
      8
    );
    const message = create(MessageRecordSchema, { sourceMessageId: "SOURCE-1", events: [short] });
    const view = renderWithProviders(
      <DayTimeline
        messages={[message]}
        {...bounds}
        interval={60}
        month
        returnTo="/calendar?view=month"
      />
    );
    for (let day = 1; day <= days; day++) {
      expect(
        view.getByRole("button", {
          name: `Open ${date.slice(0, 7)}-${String(day).padStart(2, "0")} in Day view`,
        })
      ).toBeTruthy();
    }
    view.unmount();
  }
  expect(moveMonth("2026-12-31", 1)).toBe("2027-01-01");
  expect(moveMonth("2026-03-31", -1)).toBe("2026-02-01");
});
test("calendar mounts controls and truthful loading", () => {
  const view = renderWithProviders(<Calendar />, {
    route: "/calendar?date=2026-11-04&interval=30&hours=6-12&q=watch",
  });
  expect(view.getByLabelText("UTC date")).toHaveValue("2026-11-04");
  expect(view.getByLabelText("Grid interval")).toHaveValue("30");
  expect(view.getByRole("searchbox", { name: "Search schedule" })).toHaveValue("watch");
  const search = view.getByRole("searchbox", { name: "Search schedule" });
  expect(search.closest("section")?.getAttribute("aria-label")).toBe("Calendar controls");
  expect(search).toHaveAttribute("aria-describedby", "schedule-search-hint");
  expect(view.container.querySelector("#schedule-search-hint")?.textContent).toContain(
    "not just this period"
  );
  expect(view.getByRole("status").textContent).toContain("Loading schedule");
});
test("shared matching keeps all events from source-only matches and caps current future starts", () => {
  const events = Array.from({ length: 8 }, (_, i) => ({
    ...event,
    id: BigInt(i + 1),
    startAt: timestampFromDate(new Date(midnight + i * HOUR)),
    endAt: timestampFromDate(new Date(midnight + (i + 0.5) * HOUR)),
    isRevised: i === 3,
  }));
  const message = create(MessageRecordSchema, {
    sourceMessageId: "SOURCE-1",
    rawText: "Copper lantern",
    events: events.reverse(),
  });
  const result = discover([message], "COPPER LANTERN", midnight + HOUR);
  expect(result.messages[0].events).toHaveLength(8);
  expect(result.upcoming.map(({ event: e }) => e.id)).toEqual([2n, 3n, 4n, 5n, 6n]);
  expect(discover([message], "no match", midnight).messages).toHaveLength(0);
  const unresolved = create(MessageRecordSchema, {
    sourceMessageId: "REVIEW",
    processingStatus: "needs_review",
    rawText: "pending coordination",
  });
  expect(discover([unresolved], "pending", midnight).review).toHaveLength(1);
  expect(discover([unresolved], "pending", midnight).upcoming).toHaveLength(0);
  expect(discover([message], "", midnight + 100 * HOUR).upcoming).toHaveLength(0);
});
test("continuous geometry clips without rounding and excludes invalid intervals", () => {
  const full = geometry(event, midnight, midnight + 24 * HOUR)!;
  expect(full.left).toBeCloseTo((8.25 / 24) * 100);
  expect(full.width).toBeCloseTo((0.25 / 24) * 100);
  const clipped = geometry(event, midnight + 8.3 * HOUR, midnight + 9 * HOUR)!;
  expect(clipped.left).toBe(0);
  expect(clipped.before).toBe(true);
  expect(clipped.width).toBeCloseTo((0.2 / 0.7) * 100);
  expect(
    geometry({ ...event, scheduleStatus: "needs_review" }, midnight, midnight + 24 * HOUR)
  ).toBeNull();
  expect(geometry({ ...event, endAt: event.startAt }, midnight, midnight + 24 * HOUR)).toBeNull();
  expect(geometry(event, midnight + 8.5 * HOUR, midnight + 9 * HOUR)).toBeNull();
  expect(utcDate("2026-02-30", "2026-11-04")).toBe("2026-11-04");
});
test("timeline keeps exact labels and authoritative source links", () => {
  const message = create(MessageRecordSchema, { sourceMessageId: "SOURCE-1", events: [event] });
  const view = renderWithProviders(
    <DayTimeline
      messages={[message]}
      from={midnight}
      to={midnight + 24 * HOUR}
      interval={30}
      returnTo="/calendar?date=2026-11-04&q=watch"
    />
  );
  expect(view.getAllByText(/2026-11-04 08:15 UTC/).length).toBeGreaterThan(0);
  expect(view.queryByRole("heading", { name: /Exact event details/ })).toBeNull();
  expect(view.container.querySelector(".calendar-details")).toBeNull();
  expect(
    view.getByRole("link", { name: "Short event, source record" }).getAttribute("href")
  ).toContain("record=SOURCE-1");
});
