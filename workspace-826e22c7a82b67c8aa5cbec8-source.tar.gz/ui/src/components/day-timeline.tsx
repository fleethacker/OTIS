import { Link, useNavigate } from "react-router-dom";
import { useMemo, type ReactNode } from "react";
import { Calendar, type EventProps } from "react-big-calendar";
import type { MessageRecord, ExtractedEvent } from "../gen/app/v1/models_pb";
import { instant, geometry } from "./calendar-time";
import { calendarLocalizer } from "./calendar-localizer";
import { messageHref } from "./calendar-links";
import { useDisplayTime, civilDate, civilHour } from "./display-time";
import moment from "moment-timezone";

interface ScheduleEntry {
  message: MessageRecord;
  event: ExtractedEvent;
  start: Date;
  end: Date;
  title: string;
  href: string;
  before: boolean;
  after: boolean;
}
function EventContent({ event: row }: EventProps<ScheduleEntry>) {
  const { format: utc } = useDisplayTime();
  return (
    <Link to={row.href} aria-label={`${row.title}, source record`}>
      <strong>{row.title}</strong>
      {row.event.isRevised && " · Revised"}
      <span className="calendar-event-time">
        {utc(row.event.startAt)} → {utc(row.event.endAt)}
      </span>
      {row.before && <span className="calendar-continuation"> · Continues from earlier</span>}
      {row.after && <span className="calendar-continuation"> · Continues later</span>}
    </Link>
  );
}

export function DayTimeline({
  messages,
  from,
  to,
  interval,
  returnTo,
  month = false,
  onDay,
}: {
  messages: MessageRecord[];
  from: number;
  to: number;
  interval: number;
  returnTo: string;
  month?: boolean;
  onDay?: (date: string) => void;
}) {
  const navigate = useNavigate();
  const { zone, mode, label } = useDisplayTime();
  const localizer = useMemo(() => calendarLocalizer(zone), [zone]);
  const rows: ScheduleEntry[] = messages
    .flatMap((message) =>
      message.events.flatMap((event) => {
        const position = geometry(event, from, to);
        return position
          ? [
              {
                message,
                event,
                start: new Date(instant(event.startAt)),
                end: new Date(instant(event.endAt)),
                title: event.title,
                href: messageHref(message.sourceMessageId, returnTo),
                before: position.before,
                after: position.after,
              },
            ]
          : [];
      })
    )
    .sort((a, b) => +a.start - +b.start);
  const midnight = civilHour(civilDate(new Date(from), zone), 0, zone);
  return (
    <>
      {rows.length === 0 && (
        <div className="unfinished">
          <h3>No timed events in this {month ? "month" : "window"}</h3>
          <p>
            Try another {label} {month ? "month" : "day or a wider hours window"}. Unresolved
            schedules are not plotted.
          </p>
        </div>
      )}
      <div
        className="calendar-scroll"
        role="region"
        aria-label={`${mode === "utc" ? "Zulu UTC" : label} calendar, scrollable`}
        tabIndex={0}
      >
        <Calendar<ScheduleEntry>
          className="ship-calendar"
          key={`${zone}-${from}-${to}`}
          localizer={localizer}
          date={new Date(midnight)}
          view={month ? "month" : "day"}
          views={["day", "month"]}
          toolbar={false}
          events={rows}
          onNavigate={(date) => onDay?.(civilDate(date, zone))}
          onView={() => {
            /* View is owned by the URL controls. */
          }}
          onDrillDown={(date) => onDay?.(civilDate(date, zone))}
          onSelectEvent={(row) => {
            void navigate(row.href);
          }}
          selectable={false}
          showMultiDayTimes
          dayLayoutAlgorithm="no-overlap"
          popup
          step={interval}
          timeslots={1}
          min={new Date(from)}
          max={new Date(to - 1)}
          scrollToTime={new Date(from)}
          getNow={() => new Date()}
          tooltipAccessor={() => ""}
          eventPropGetter={(row) => ({ className: row.event.isRevised ? "calendar-revised" : "" })}
          formats={{
            timeGutterFormat: (date) =>
              moment.tz(date, zone).format(mode === "utc" ? "HH:mm" : "HH:mm [UTC]Z"),
            dayHeaderFormat: (date) => `${moment.tz(date, zone).format("dddd DD MMMM")} · ${label}`,
            eventTimeRangeFormat: () => "",
          }}
          components={{
            event: EventContent,
            // Public 1.20 hook; @types 1.16 predates it. Suppress a retained
            // indicator when changing to a window that excludes the real now.
            ...{
              timeIndicatorWrapper: ({ children }: { children?: ReactNode }) =>
                Date.now() >= from && Date.now() < to ? children : null,
            },
            month: {
              dateHeader: ({ date, label }) => (
                <button
                  className="btn btn-ghost btn-xs"
                  aria-label={`Open ${civilDate(date, zone)} in Day view`}
                  onClick={() => onDay?.(civilDate(date, zone))}
                >
                  {label}
                </button>
              ),
            },
          }}
        />
      </div>
    </>
  );
}
