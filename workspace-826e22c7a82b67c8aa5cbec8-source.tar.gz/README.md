# Ark-generated application

This repository contains a Go application with an embedded React UI, ConnectRPC
services, ENT persistence, and bundled Ark framework libraries in `ark/`.
The Go module replacement and Bun workspace already select those local
libraries; there is no separate framework package to install.

See [local development and source handoff](docs/ark-handoff.md) for prerequisites,
build and test commands, code generation, and the meaning of exported project
context. Coding assistants should start with [AGENTS.md](AGENTS.md).

Run these commands from the repository root after completing the documented
prerequisites:

```bash
bun install --frozen-lockfile
ark run job build
ark run stage tests
ark run stage checks
```

Application-specific setup and deployment requirements belong in this README
as the application evolves. Consult the included license files for applicable
terms.

## Watch Desk data source

Ship schedules currently use persisted, explicitly fictional USS Meridian
examples, not an operational backend or validated USMTF. See
[source data and integration notes](docs/source-data.md) for startup, empty-data
configuration, the shared read RPC, evidence semantics and verification.
